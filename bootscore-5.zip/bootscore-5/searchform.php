<!-- Search Button Outline Secondary Right -->
<form class="searchform input-group" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="form-inline">
    <input type="text" name="s" class="form-control" placeholder="<?php _e('Search', 'bootscore'); ?>">
    <button type="submit" class="input-group-text btn btn-outline-secondary"><i class="fas fa-search"></i></button>
</form>
